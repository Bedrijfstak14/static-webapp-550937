<!DOCTYPE html>
<html lang="en" class="h-full">
  <head>
    <title>Invoice Ninja</title>

    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="theme-color" content="#000000" />
    <meta
      name="description"
      content="Leading free invoice generator for freelancers and small businesses. Invoice clients, accept payments, track expenses &amp; time billable-tasks online."
    />

    <link rel="stylesheet" href="/rsms/inter.css" />

    <link rel="icon" href="/favicon.ico" />
    <link rel="apple-touch-icon" href="/logo192.png" />
    <link rel="manifest" href="/manifest.json" />
    <script type="module" crossorigin src="/bundle.9abe88c8.js"></script>
    <link rel="stylesheet" href="/index-1d54d85a.css">
  </head>

  <body class="h-full">
    <noscript>You need to enable JavaScript to run this app.</noscript>
    <div id="root"></div>
    
  </body>
</html>
<?php /**PATH /app/code/resources/views/react/index.blade.php ENDPATH**/ ?>